use todolist;


SHOW TABLES;

INSERT INTO notas (titulo, conteudo) VALUES ('Nota de Teste', 'Este é um conteúdo de teste');

ALTER TABLE notas ADD COLUMN cor VARCHAR(7);

DESCRIBE n;





SELECT * FROM notas;

use todolist;

CREATE TABLE kanbam (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    status ENUM('ToDo', 'InProgress', 'Done') DEFAULT 'ToDo',
    priority ENUM('Urgente', 'Intermediario', 'NaoUrgente') DEFAULT 'NaoUrgente',
    due_date DATE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


ALTER TABLE kanbam ADD COLUMN due_date DATE NULL,
 VARCHAR(255);


DROP TABLE kanbam;

CREATE TABLE kanbam (
    id INT AUTO_INCREMENT PRIMARY KEY,
    content VARCHAR(255) NOT NULL,
    status ENUM('notStarted', 'started', 'urgent') NOT NULL
);

INSERT INTO kanbam (content, status) VALUES
('Tarefa 1', 'notStarted'),
('Tarefa 2', 'started'),
('Tarefa 3', 'urgent');

SELECT * FROM kanbam;


USE kanban;

CREATE TABLE kanlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    status ENUM('not_started', 'in_progress', 'urgent') NOT NULL DEFAULT 'not_started'
);

SELECT *FROM listkan;

DROP TABLE kanlist;

CREATE TABLE kanlist (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255),
  description TEXT,
  due_date DATE,
  status VARCHAR(50)
);

USE todolist;


DROP TABLE kanlist;

CREATE TABLE kanlist (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE NULL,
    status ENUM('not_started', 'in_progress', 'urgent') NOT NULL DEFAULT 'not_started'
);

DROP TABLE kanlist;

CREATE TABLE kanlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    status ENUM('não-comecou', 'em-progresso', 'concluído') NOT NULL
);

CREATE TABLE kantask (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    description TEXT,
    status ENUM('Não Começou', 'Começou', 'Concluído') NOT NULL
);

SELECT * FROM kantask;
SELECT * FROM kantask;

SHOW TABLES;

use todolist;

DROP TABLE kantask;

CREATE TABLE listkan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE,
    description TEXT,
    status ENUM('nao_comecou', 'comecou', 'urgente') DEFAULT 'nao_comecou'
);

CREATE DATABASE kanban_db;

USE kanban_db;

CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    date DATE,
    description TEXT,
    status ENUM('nao_comecou', 'comecou', 'urgente') DEFAULT 'nao_comecou'
);
