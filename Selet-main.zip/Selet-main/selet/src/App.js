import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Projetos from './components/pages/Projetos';
import Home from './components/pages/Home';
import Suporte from './components/pages/Suporte';
import NewProject from './components/pages/NewProject';
import Container from './components/Layout/Container';
import NavBar from './components/Layout/NavBar';
import Footer from './components/Layout/Footer';
import Homeproject from './AreaProjects/Homeproject';
import TodoList from './AreaProjects/todolis/todolist';
import BlocoNotas from './AreaProjects/BlocoNotas/BlocoNotas';
import Kanban from './AreaProjects/Kanbam/Kanban';
// Rota para o Home do Projeto

function App() {
  return (
    <Router>
      <div>
        <NavBar />
        <Container customClass="min-height">
          <Routes>
            <Route exact path="/projetos" element={<Projetos />} />
            <Route exact path="/home" element={<Home />} />
            <Route exact path="/suporte" element={<Suporte />} />
            <Route exact path="/newproject" element={<NewProject />} />
            <Route exact path="/homeproject" element={<Homeproject />} />
            <Route exact path="/todolist" element={<TodoList />} />
            <Route exact path="/notas" element={<BlocoNotas />} />
            <Route exact path="/kanbam" element={<Kanban />} />
          </Routes>

        </Container>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
