import React from 'react';
import styles from './ProjectCard.module.css';
import { BsFillTrashFill } from 'react-icons/bs';
import { Link } from'react-router-dom';

function ProjectCard({ id, name, start_date, category, handleRemove }) {

    return (
        <div className={styles.project_card}>
            <h4 className={styles.project_name}>{name}</h4>
            <div className={styles.margin}>
                <p className={styles.date}>
                    <span>Data:</span> {start_date}
                </p>
                <p className={styles.category}>
                    <span></span> {category}
                </p>
            </div>
            <div className={styles.actions}>
            <Link to="/homeproject" className={styles.link_button}>
Entrar
</Link>
                <button onClick={(e) => { e.preventDefault(); handleRemove(id); }}>
                    <BsFillTrashFill /> Excluir
                </button>
            </div>
        </div>
    );
}

export default ProjectCard;
