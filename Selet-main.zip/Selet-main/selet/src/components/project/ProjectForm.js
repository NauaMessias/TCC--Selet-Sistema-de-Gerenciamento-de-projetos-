import { useState, useEffect } from 'react';
import styles from './ProjectForm.module.css';
import Input from '../form/Input';
import Select from '../form/Select';
import SubmitButton from '../form/SubmitButton';

function ProjectForm({ handleSubmit, btnText, data }) {
    const [categories, setCategories] = useState([]);
    const [project, setProject] = useState(data || {});

    // Carrega as categorias da API ao carregar o componente
    useEffect(() => {
        fetch("http://localhost:5000/categories", {
            method: "GET",
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then((resp) => resp.json())
            .then((data) => {
                console.log('Fetched categories:', data); // Verifique os dados
                setCategories(data); // Atualiza as categorias
            })
            .catch((err) => console.log(err));
    }, []);

    // Função para envio do formulário
    const submit = (e) => {
        e.preventDefault();
        handleSubmit(project); // Envia o projeto para a função de manipulação
    };

    // Função para lidar com mudanças em campos de texto
    function handleChange(e) {
        setProject({ ...project, [e.target.name]: e.target.value });
    }

    // Função para lidar com a mudança de categoria
    function handleCategory(e) {
        const selectedOption = e.target.options[e.target.selectedIndex];
        setProject({
            ...project,
            category: {
                id: e.target.value,
                name: selectedOption.text, // Captura o texto da categoria
            },
        });
    }

    return (
        <div>
            <form onSubmit={submit} className={styles.form}>
                <Input 
                    type="text"
                    text="Nome do Projeto"
                    name="name"
                    placeholder="Insira o nome do seu novo projeto"
                    handleOnChange={handleChange}
                    value={project.name || ''}
                />
                <Input
                    type="date"
                    text="Data de Termino"
                    name="start_date"
                    handleOnChange={handleChange}
                    value={project.start_date || ''}
                />
                <Select 
                    name="category_id"
                    text="Selecione a Categoria"
                    options={categories} 
                    handleOnChange={handleCategory}
                    value={project.category ? project.category.id : ''}
                />
                <SubmitButton text={btnText} />
            </form>
        </div>
    );
}

export default ProjectForm;
