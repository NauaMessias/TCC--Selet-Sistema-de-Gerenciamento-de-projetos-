import styles from './Busca.module.css';
import { FaSearch } from 'react-icons/fa';
import { useState } from'react';

function Busca({ handleSearch }) {
    const [searchTerm, setSearchTerm] = useState('');

    const handleChange = (e) => {
        setSearchTerm(e.target.value);
        handleSearch(e.target.value);
    };

    return (
        <div className={styles.busca}>
            <input 
                type="text"
                placeholder="Pequise seus projetos"
                value={searchTerm}
                onChange={handleChange}
            />
            <FaSearch />
        </div>
    );
}

export default Busca;
