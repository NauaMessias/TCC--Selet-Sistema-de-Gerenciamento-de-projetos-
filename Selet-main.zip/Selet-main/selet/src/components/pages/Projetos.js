import { useLocation } from "react-router-dom";
import React, { useState, useEffect } from "react";

import Container from '../Layout/Container'; 
import Message from "../Layout/Message";
import LinkButton from '../Layout/LinkButton';
import ProjectCard from '../project/ProjectCard';
import Loading from '../Layout/Loading';
import Busca from "../busca/Busca";

import styles from './Projetos.module.css';

function Projetos() {
    const [projects, setProjects] = useState([]);
    const [filteredProjects, setFilteredProjects] = useState([]);
    const [removeLoading, setLoading] = useState(false);
    const [projectMessage, setProjectMessage] = useState('');
    
    const location = useLocation();
    let message = location.state ? location.state.message : '';

    useEffect(() => {
        setTimeout(() => {
            fetch("http://localhost:5000/projects", {
                method: "GET",
                headers: {
                    'Content-Type': 'application/json',
                },
            })
                .then((resp) => resp.json())
                .then((data) => {
                    setProjects(data);
                    setFilteredProjects(data); // Initialize filteredProjects
                    setLoading(true);
                })
                .catch((err) => console.log(err));
        }, 2000); // Simulating loading
    }, []); 

    function removeProject(id) {
        setLoading(true);
        fetch(`http://localhost:5000/projects/${id}`, {
            method: "DELETE",
            headers: {
                'Content-Type': 'application/json',
            },
        })
        .then(resp => resp.json())
        .then(() => {
            const updatedProjects = projects.filter((project) => project.id !== id);
            setProjects(updatedProjects);
            setFilteredProjects(updatedProjects); // Also update the filtered list
            setProjectMessage('Projeto removido com sucesso!');
        });
    }

    // Filter projects based on search term
    const handleSearch = (term) => {
        const filtered = projects.filter(project => 
            project.name.toLowerCase().includes(term.toLowerCase())
        );
        setFilteredProjects(filtered);
    };

    return (
        <div className={styles.project_containe}>
            <div className={styles.title_containe}>
                <Busca handleSearch={handleSearch} />
                <LinkButton to="/newproject" text="Criar Projeto"/>
            </div>
            {message && <Message type="success" msg={message} />}
            {projectMessage && <Message type="success" msg={projectMessage} />}
            <Container customClass="start">
                {filteredProjects.length > 0 ? (
                    filteredProjects.map((project) => (
                        <ProjectCard 
                            name={project.name}
                            id={project.id}
                            start_date={project.start_date}
                            category={project.category?.name || 'Sem Categoria'}
                            key={project.id}
                            handleRemove={removeProject}
                        />
                    ))
                ) : 
                    removeLoading ? (
                        <div className={styles.text_aviso}>
                            <h3>Não há nenhum projeto</h3>
                            
                            <LinkButton to="/newproject" text="Criar Projeto"/>
                        </div>
                    ):(
                        <Loading />
                    ) 
                } 
            </Container>
        </div>
    );
}

export default Projetos;
