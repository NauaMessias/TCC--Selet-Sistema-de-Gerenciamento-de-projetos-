import React from 'react';
import ProjectForm from '../project/ProjectForm';
import styles from './NewProject.module.css';
import { useNavigate } from 'react-router-dom';

function NewProject() {
    const navigate = useNavigate();

    function createPost(project) {
        // Inicializar cost e services
        project.cost = 0;
        project.services = [];

        fetch("http://localhost:5000/projects", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(project),
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            // Redirecionar para a rota de projetos após a criação bem-sucedida
            navigate('/projetos', { state: { message: 'Projeto criado com sucesso' } });        })
        .catch(err => console.error(err));
    }

    return (
        <div className={styles.newproject_container}>
            <h1>Criar novo Projeto</h1>
            <p>Um pequeno passo, mas uma grande conquista!</p>
            <ProjectForm handleSubmit={createPost} btnText="Criar Projeto" />
        </div>
    );
}

export default NewProject;