import styles from './Home.module.css'
import img_inicial from '../../img/img_inicial.png'

import LinkButton from '../Layout/LinkButton';

function Home(){
    return (

        <section className={styles.home_container}>
            <div className={styles.home_text}>

            <h1> Bem-vindo ao Selet!</h1>

            <p>O Selet é a sua plataforma online para gerencia tudo com facilidade Aproveite a experiência simples e intuitiva do nosso sistema.</p>

            <LinkButton to="/newproject" text="Criar novo projeto" />

            </div>

            <img src={img_inicial} alt="Selet" className={styles.home_img} />
        </section>
    );
}

export default Home;