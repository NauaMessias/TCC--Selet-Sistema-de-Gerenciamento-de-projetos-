import {Link } from "react-router-dom";

import Container from "./Container";

import styles from "./NavBar.module.css";
import logo from "../../img/logo.png"

function NavBar(){
    return (<nav className={styles.navbar}>
        <img src={logo} alt="Logo" className={styles.logo}/>
           <Container>
       <ul class={styles.list}>
        <li class={styles.item}> <Link to="/home">Home</Link></li>

        <li class={styles.item}> <Link to="/projetos">Projetos</Link></li>

        <li class={styles.item}> <Link to="/suporte">Suporte</Link></li>

        <li class={styles.item}> <Link to="/newproject">Novo Projeto</Link></li>

       </ul>
           </Container>
    </nav>);
}

export default NavBar;