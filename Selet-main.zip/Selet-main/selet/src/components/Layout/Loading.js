import styles from './Loading.module.css'

import logo from '../../img/logo.svg'


function Loading() {
    return (
        <div className={styles.loader_container}>
            <img src={logo} alt="Logo" className={styles.loader}/>
        </div>
    );
}

export default Loading;