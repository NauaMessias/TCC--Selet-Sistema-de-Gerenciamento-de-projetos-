import { useState,useEffect  } from "react";
import React from 'react';
import styles from './Message.module.css';

function Message({ type, msg }) {

    const[visible, setvisible] = useState(false)

    useEffect(() => {
        setvisible(true)
        setTimeout(() => setvisible(false), 3000)
    }, [msg])   
    if (!msg) return null;


    return (<>
    {visible && <div className={styles.sucesso}>
        {msg}
    </div>}
        </>);
}

export default Message;