import React from "react";
import Subbar from './Layout/Subbar'

function Homeproject(){
    return(
       <>
        <Subbar/>
       </>
    )
}

export default Homeproject;