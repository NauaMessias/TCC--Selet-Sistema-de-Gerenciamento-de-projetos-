import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaEdit, FaTrash } from 'react-icons/fa'; 
import { Link } from 'react-router-dom';
import './todolist.css';

const PRIORITIES = {
    URGENTE: 'urgente',
    INTERMEDIARIO: 'intermediário',
    NAO_URGENTE: 'não-urgente'
};

function TodoList() {
    const [tasks, setTasks] = useState([]);
    const [taskName, setTaskName] = useState('');
    const [taskDate, setTaskDate] = useState('');
    const [priority, setPriority] = useState(PRIORITIES.NAO_URGENTE);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        loadTasks(); 
    }, []);

    const loadTasks = () => {
        axios.get('http://localhost:3002/tasks') // Alterado para a porta 3002
            .then(response => setTasks(response.data))
            .catch(error => console.error('Erro ao carregar tarefas:', error));
    };

    const handleAddTask = () => {
        if (!taskName || !taskDate) {
            alert('Por favor, preencha todos os campos.');
            return;
        }

        const dateObj = new Date(taskDate);
        if (isNaN(dateObj)) {
            alert('Data inválida. Por favor, insira uma data válida.');
            return;
        }

        const newTask = { 
            name: taskName, 
            date: dateObj.toISOString().split('T')[0],
            priority: priority, 
            completed: false 
        };

        axios.post('http://localhost:3002/tasks', newTask) // Alterado para a porta 3002
            .then(response => {
                setTasks(prevTasks => [...prevTasks, { ...newTask, id: response.data.id }]);
                setTaskName('');
                setTaskDate('');
                setPriority(PRIORITIES.NAO_URGENTE);
            })
            .catch(error => console.error('Erro ao adicionar tarefa:', error));
    };

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleToggleTaskCompletion = (id) => {
        const taskToToggle = tasks.find(task => task.id === id);
        if (taskToToggle) {
            const updatedTask = { ...taskToToggle, completed: !taskToToggle.completed };
            axios.put(`http://localhost:3002/tasks/${id}`, updatedTask) // Alterado para a porta 3002
                .then(() => {
                    setTasks(tasks.map(t => t.id === id ? updatedTask : t));
                })
                .catch(error => console.error('Erro ao marcar como completada a tarefa:', error));
        }
    };

    const handleEditTask = (id) => {
        const task = tasks.find(task => task.id === id);
        if (task) {
            const newName = prompt("Novo nome da tarefa:", task.name);
            const newDate = prompt("Nova data da tarefa (AAAA-MM-DD):", task.date);
            const newPriority = prompt("Nova prioridade (urgente/intermediário/não-urgente):", task.priority);
        
            if (newName && newDate && newPriority) {
                const formattedDate = new Date(newDate);
                if (isNaN(formattedDate)) {
                    alert('Data inválida. Por favor, insira uma data válida.');
                    return;
                }
                axios.put(`http://localhost:3002/tasks/${id}`, { ...task, name: newName, date: formattedDate.toISOString().split('T')[0], priority: newPriority }) // Alterado para a porta 3002
                    .then(() => {
                        setTasks(tasks.map(t => t.id === id ? { ...t, name: newName, date: formattedDate.toISOString().split('T')[0], priority: newPriority } : t));
                    })
                    .catch(error => console.error('Erro ao editar tarefa:', error));
            }
        }
    };

    const handleDeleteTask = (id) => {
        if (id === undefined) {
            console.error('ID da tarefa é indefinido');
            return;
        }
        axios.delete(`http://localhost:3002/tasks/${id}`) // Alterado para a porta 3002
            .then(() => {
                setTasks(prevTasks => prevTasks.filter(task => task.id !== id));
            })
            .catch(error => console.error('Erro ao excluir tarefa:', error));
    };

    const filteredTasks = tasks.filter(task => 
        task.name && task.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const counts = {
        urgente: tasks.filter(task => task.priority === PRIORITIES.URGENTE).length,
        intermediario: tasks.filter(task => task.priority === PRIORITIES.INTERMEDIARIO).length,
        naoUrgente: tasks.filter(task => task.priority === PRIORITIES.NAO_URGENTE).length,
    };

    const sortedTasks = filteredTasks.sort((a, b) => {
        const priorityOrder = { [PRIORITIES.URGENTE]: 1, [PRIORITIES.INTERMEDIARIO]: 2, [PRIORITIES.NAO_URGENTE]: 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    return (
        <div className="todo-list-container">
            <div className="todo-list">
                <h2>To-Do List</h2>
                <div className="task-input">
                    <input
                        type="text"
                        placeholder="Nome da tarefa"
                        value={taskName}
                        onChange={(e) => setTaskName(e.target.value)}
                    />
                    <input
                        type="date"
                        value={taskDate}
                        onChange={(e) => setTaskDate(e.target.value)}
                    />
                    <select value={priority} onChange={(e) => setPriority(e.target.value)}>
                        <option value={PRIORITIES.NAO_URGENTE}>Não Urgente</option>
                        <option value={PRIORITIES.INTERMEDIARIO}>Intermediário</option>
                        <option value={PRIORITIES.URGENTE}>Urgente</option>
                    </select>
                    <button onClick={handleAddTask}>Adicionar Tarefa</button>
                </div>

                <div className="tasks-container">
                    <ul>
                        {sortedTasks.map(task => (
                            <li key={task.id} className={`task-item ${task.priority}`}>
                                <span onClick={() => handleToggleTaskCompletion(task.id)} style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
                                    {task.name}
                                </span>
                                <span>{new Date(task.date).toLocaleDateString('pt-BR')}</span>
                                <button onClick={() => handleEditTask(task.id)}>
                                    <FaEdit />
                                </button>
                                <button className="delete-button" onClick={() => handleDeleteTask(task.id)}>
                                    <FaTrash />
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            <div className="sidebar">
                <input
                    type="text"
                    placeholder="Buscar tarefa..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="search-bar"
                />
                <div className="task-counts">
                    <div className="task-count urgente">Urgentes: {counts.urgente}</div>
                    <div className="task-count intermediario">Intermediárias: {counts.intermediario}</div>
                    <div className="task-count nao-urgente">Não Urgentes: {counts.naoUrgente}</div>
                </div>
            </div>

            <Link to="/Homeproject" className="back-link">Voltar</Link>
        </div>
    );
}

export default TodoList;
