import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './BlocoNotas.css';
import { Link } from 'react-router-dom';

const BlocoNotas = () => {
    const [notas, setNotas] = useState([]);
    const [titulo, setTitulo] = useState('');
    const [conteudo, setConteudo] = useState('');
    const [cor, setCor] = useState('#ffffff');
    const [editandoNotaId, setEditandoNotaId] = useState(null);
    const [pesquisa, setPesquisa] = useState('');

    // Carregar notas ao montar o componente
    useEffect(() => {
        fetchNotas();
    }, []);

    // Função para buscar notas do servidor
    const fetchNotas = async () => {
        try {
            const response = await axios.get('http://localhost:3002/api/notas'); // Ajuste para a porta 3002
            setNotas(response.data);
        } catch (error) {
            console.error('Erro ao buscar notas:', error);
            alert('Erro ao buscar notas. Tente novamente mais tarde.');
        }
    };

    // Função para salvar ou atualizar uma nota
    const salvarNota = async () => {
        if (!titulo || !conteudo) {
            alert('Por favor, preencha o título e o conteúdo da nota.'); // Alerta se campos estiverem vazios
            return;
        }

        try {
            if (editandoNotaId) {
                await axios.put(`http://localhost:3002/api/notas/${editandoNotaId}`, { titulo, conteudo, cor });
            } else {
                await axios.post('http://localhost:3002/api/notas', { titulo, conteudo, cor });
            }
            resetFormulario();
            fetchNotas();
        } catch (error) {
            console.error('Erro ao salvar nota:', error);
            alert('Erro ao salvar nota. Tente novamente mais tarde.');
        }
    };

    // Função para editar uma nota
    const editarNota = (nota) => {
        setTitulo(nota.titulo);
        setConteudo(nota.conteudo);
        setCor(nota.cor);
        setEditandoNotaId(nota.id);
    };

    // Função para excluir uma nota
    const excluirNota = async (id) => {
        try {
            await axios.delete(`http://localhost:3002/api/notas/${id}`);
            fetchNotas();
            resetFormulario();
        } catch (error) {
            console.error('Erro ao excluir nota:', error);
            alert('Erro ao excluir nota. Tente novamente mais tarde.');
        }
    };

    // Função para excluir todas as notas
    const excluirTodasNotas = async () => {
        try {
            await Promise.all(notas.map(nota => axios.delete(`http://localhost:3002/api/notas/${nota.id}`)));
            fetchNotas();
            resetFormulario();
        } catch (error) {
            console.error('Erro ao excluir todas as notas:', error);
            alert('Erro ao excluir todas as notas. Tente novamente mais tarde.');
        }
    };

    // Função para resetar o formulário
    const resetFormulario = () => {
        setTitulo('');
        setConteudo('');
        setCor('#ffffff');
        setEditandoNotaId(null);
    };

    // Filtra notas baseado na pesquisa
    const notasFiltradas = notas.filter(nota =>
        nota.titulo.toLowerCase().includes(pesquisa.toLowerCase()) || 
        nota.conteudo.toLowerCase().includes(pesquisa.toLowerCase())
    );

    return (
        <div className="bloco-notas">
            <div className="formulario">
                <h2>Bloco de Notas</h2>
                <input
                    type="text"
                    placeholder="Título"
                    value={titulo}
                    onChange={(e) => setTitulo(e.target.value)}
                    className="input-titulo"
                />
                <textarea
                    placeholder="Conteúdo"
                    value={conteudo}
                    onChange={(e) => setConteudo(e.target.value)}
                    className="textarea-conteudo"
                />
                <div className="cor-selecionada" style={{ backgroundColor: cor }} aria-label="Cor selecionada"></div>
                <input
                    type="color"
                    value={cor}
                    onChange={(e) => setCor(e.target.value)}
                    className="seletor-cor"
                />
                <button className='salva-notas' onClick={salvarNota}>
                    {editandoNotaId ? 'Atualizar Nota' : 'Salvar Nota'}
                </button>
                <input
                    type="text"
                    placeholder="Pesquisar..."
                    value={pesquisa}
                    onChange={(e) => setPesquisa(e.target.value)}
                    className="input-pesquisa"
                />
                <button onClick={excluirTodasNotas} className="botao-excluir-todas">Excluir Todas</button>
                <Link to="/Homeproject" className="link-voltar">Voltar</Link>
            </div>

            <div className="lista-notas">
                {notasFiltradas.map((nota) => (
                    <div
                        key={nota.id}
                        className="nota"
                        style={{
                            backgroundColor: nota.cor,
                            color: getContrastingColor(nota.cor),
                        }}
                    >
                        <h3>{nota.titulo}</h3>
                        <p>{nota.conteudo}</p>
                        <button onClick={() => editarNota(nota)}>Editar</button>
                        <button onClick={() => excluirNota(nota.id)}>Excluir</button>
                    </div>
                ))}
            </div>
        </div>
    );

    // Função para obter a cor de contraste
    function getContrastingColor(hexColor) {
        if (!hexColor) return '#000000'; 
        const r = parseInt(hexColor.slice(1, 3), 16);
        const g = parseInt(hexColor.slice(3, 5), 16);
        const b = parseInt(hexColor.slice(5, 7), 16);
        const brightness = (r * 299 + g * 587 + b * 114) / 255000;
        return brightness > 0.5 ? '#000000' : '#FFFFFF';
    }
};

export default BlocoNotas;
