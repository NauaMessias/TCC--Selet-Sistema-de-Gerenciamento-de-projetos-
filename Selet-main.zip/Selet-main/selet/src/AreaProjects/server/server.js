const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
require('dotenv').config();

app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err);
        process.exit(1);
    }
    console.log('Conectado ao MySQL');
});

const handleError = (res, err, message) => {
    console.error(err);
    res.status(500).send(message);
};

app.get('/tasks', (req, res) => {
    db.query('SELECT * FROM tasks', (err, results) => {
        if (err) return handleError(res, err, "Erro ao buscar tarefas.");
        res.json(results);
    });
});

app.post('/tasks', (req, res) => {
    const { name, date, priority } = req.body;
    db.query('INSERT INTO tasks (name, date, priority, completed) VALUES (?, ?, ?, ?)', 
    [name, date, priority, false], (err) => {
        if (err) return handleError(res, err, "Erro ao salvar tarefa.");
        res.sendStatus(201);
    });
});

app.put('/tasks/:id', (req, res) => {
    const { id } = req.params;
    const { name, date, priority, completed } = req.body;
    db.query('UPDATE tasks SET name = ?, date = ?, priority = ?, completed = ? WHERE id = ?', 
    [name, date, priority, completed, id], (err) => {
        if (err) return handleError(res, err, "Erro ao atualizar tarefa.");
        res.sendStatus(200);
    });
});

app.delete('/tasks/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM tasks WHERE id = ?', [id], (err) => {
        if (err) return handleError(res, err, "Erro ao excluir tarefa.");
        res.sendStatus(204);
    });
});

// Rota para notas
app.get('/api/notas', (req, res) => {
    db.query('SELECT * FROM notas', (err, results) => {
        if (err) return handleError(res, err, "Erro ao buscar notas.");
        res.json(results);
    });
});

app.post('/api/notas', (req, res) => {
    const { titulo, conteudo, cor } = req.body;
    db.query('INSERT INTO notas (titulo, conteudo, cor) VALUES (?, ?, ?)', 
    [titulo, conteudo, cor], (err) => {
        if (err) return handleError(res, err, "Erro ao salvar nota.");
        res.sendStatus(201);
    });
});

app.put('/api/notas/:id', (req, res) => {
    const { id } = req.params;
    const { titulo, conteudo, cor } = req.body;
    db.query('UPDATE notas SET titulo = ?, conteudo = ?, cor = ? WHERE id = ?', 
    [titulo, conteudo, cor, id], (err) => {
        if (err) return handleError(res, err, "Erro ao atualizar nota.");
        res.sendStatus(200);
    });
});

app.delete('/api/notas/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM notas WHERE id = ?', [id], (err) => {
        if (err) return handleError(res, err, "Erro ao excluir nota.");
        res.sendStatus(204);
    });
});

// Rota para listkan
app.get('/listkan', (req, res) => {
    db.query('SELECT * FROM listkan', (err, results) => {
        if (err) return handleError(res, err, "Erro ao buscar tarefas.");
        res.json(results);
    });
});

app.post('/listkan', (req, res) => {
    const { name, date, description, status } = req.body;
    db.query(
        'INSERT INTO listkan (name, date, description, status) VALUES (?, ?, ?, ?)',
        [name, date, description, status || 'nao_comecou'],
        (err, results) => {
            if (err) return handleError(res, err, "Erro ao salvar tarefa.");
            res.status(201).json({ id: results.insertId, name, date, description, status });
        }
    );
});

app.put('/listkan/:id', (req, res) => {
    const { id } = req.params;
    const { name, date, description, status } = req.body;
    db.query(
        'UPDATE listkan SET name = ?, date = ?, description = ?, status = ? WHERE id = ?',
        [name, date, description, status, id],
        (err) => {
            if (err) return handleError(res, err, "Erro ao atualizar tarefa.");
            res.sendStatus(200);
        }
    );
});

app.delete('/listkan/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM listkan WHERE id = ?', [id], (err) => {
        if (err) return handleError(res, err, "Erro ao excluir tarefa.");
        res.sendStatus(204);
    });
});

app.get('/kantask', (req, res) => {
    db.query('SELECT * FROM listkan', (err, results) => {
        if (err) return handleError(res, err, "Erro ao buscar tarefas.");
        res.json(results);
    });
});


const PORT = 3002;  // Mude para 3003 ou qualquer outra porta livre

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
