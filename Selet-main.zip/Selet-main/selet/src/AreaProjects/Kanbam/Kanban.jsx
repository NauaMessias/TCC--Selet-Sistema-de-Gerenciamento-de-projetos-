import React, { useEffect, useState } from 'react';
import './Kanban.css';

const Kanban = () => {
    const [tasks, setTasks] = useState([]);
    const [editingTask, setEditingTask] = useState(null);
    const [taskData, setTaskData] = useState({ name: '', date: '', description: '' });
    const [newTask, setNewTask] = useState({ name: '', date: '', description: '' });
    const [draggedTask, setDraggedTask] = useState(null);

    useEffect(() => {
        fetchTasks();
    }, []);

    const fetchTasks = async () => {
        const response = await fetch('http://localhost:3003/tasks');
        const data = await response.json();
        setTasks(data);
    };

    const handleDragStart = (task) => {
        setDraggedTask(task);
    };

    const handleDrop = async (status) => {
        if (draggedTask) {
            const updatedTask = { ...draggedTask, status };
            await updateTaskInDB(updatedTask); // Atualiza no banco de dados
            setTasks(tasks.map(task =>
                task.id === draggedTask.id ? updatedTask : task
            ));
            setDraggedTask(null);
        }
    };

    const handleDragEnd = () => {
        setDraggedTask(null);
    };

    const editTask = (task) => {
        setEditingTask(task.id);
        setTaskData({ name: task.name, date: task.date, description: task.description });
    };

    const saveTask = async (id) => {
        const updatedTask = { id, ...taskData };
        await updateTaskInDB(updatedTask); // Atualiza no banco de dados
        setTasks(tasks.map(t => t.id === id ? updatedTask : t));
        setEditingTask(null);
        setTaskData({ name: '', date: '', description: '' });
    };

    const deleteTask = async (id) => {
        await deleteTaskFromDB(id); // Exclui do banco de dados
        setTasks(tasks.filter(task => task.id !== id));
    };

    const addTask = async () => {
        const newId = tasks.length ? tasks[tasks.length - 1].id + 1 : 1;
        const createdTask = { id: newId, ...newTask, status: 'nao_comecou' };
        await addTaskToDB(createdTask); // Adiciona ao banco de dados
        setTasks([...tasks, createdTask]);
        setNewTask({ name: '', date: '', description: '' });
    };

    const addTaskToDB = async (task) => {
        await fetch('http://localhost:3003/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(task),
        });
    };

    const updateTaskInDB = async (task) => {
        await fetch(`http://localhost:3003/tasks/${task.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(task),
        });
    };

    const deleteTaskFromDB = async (id) => {
        await fetch(`http://localhost:3003/tasks/${id}`, {
            method: 'DELETE',
        });
    };

    return (
        <div className="kanban-container">
            <div className="task-input">
                <input
                    type="text"
                    placeholder="Nome da tarefa"
                    value={newTask.name}
                    onChange={(e) => setNewTask({ ...newTask, name: e.target.value })}
                />
                <input
                    type="date"
                    value={newTask.date}
                    onChange={(e) => setNewTask({ ...newTask, date: e.target.value })}
                />
                <textarea
                    placeholder="Descrição"
                    value={newTask.description}
                    onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                />
                <button onClick={addTask}>Adicionar Tarefa</button>
            </div>

            <div className="kanban-columns">
                {['nao_comecou', 'comecou', 'urgente'].map((status) => (
                    <div
                        key={status}
                        className={`kanban-column ${status}`}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={() => handleDrop(status)}
                    >
                        <h2>{status.replace('_', ' ')}</h2>
                        {tasks.filter(task => task.status === status).map((task) => (
                            <div
                                key={task.id}
                                className="kanban-task"
                                draggable
                                onDragStart={() => handleDragStart(task)}
                                onDragEnd={handleDragEnd}
                            >
                                {editingTask === task.id ? (
                                    <>
                                        <input
                                            type="text"
                                            value={taskData.name}
                                            onChange={(e) => setTaskData({ ...taskData, name: e.target.value })}
                                        />
                                        <input
                                            type="date"
                                            value={taskData.date}
                                            onChange={(e) => setTaskData({ ...taskData, date: e.target.value })}
                                        />
                                        <textarea
                                            value={taskData.description}
                                            onChange={(e) => setTaskData({ ...taskData, description: e.target.value })}
                                        />
                                        <button onClick={() => saveTask(task.id)}>Salvar</button>
                                    </>
                                ) : (
                                    <div className="task-container">
                                        <h3>{task.name}</h3>
                                        <p>{task.description}</p>
                                        <span>{task.date}</span>
                                        <div>
                                            <button className="edit-button" onClick={() => editTask(task)}>Editar</button>
                                            <button className="delete-button" onClick={() => deleteTask(task.id)}>Excluir</button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Kanban;
