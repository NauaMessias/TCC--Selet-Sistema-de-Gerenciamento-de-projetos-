const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const dotenv = require('dotenv');

// Carregar variáveis de ambiente do arquivo .env
dotenv.config();

const app = express();
const port = process.env.PORT || 3003; // Define a porta padrão caso não esteja no .env

app.use(cors()); // Habilita CORS
app.use(express.json());

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados');
});

// Rota para buscar tarefas
app.get('/tasks', (req, res) => {
    db.query('SELECT * FROM tasks', (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao buscar tarefas' });
        }
        res.json(results);
    });
});

// Rota para adicionar tarefa
app.post('/tasks', (req, res) => {
    const { name, date, description, status } = req.body;
    const query = 'INSERT INTO tasks (name, date, description, status) VALUES (?, ?, ?, ?)';
    db.query(query, [name, date, description, status], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao adicionar tarefa' });
        }
        res.status(201).json({ id: results.insertId, name, date, description, status });
    });
});

// Rota para atualizar tarefa
app.put('/tasks/:id', (req, res) => {
    const { id } = req.params;
    const { name, date, description, status } = req.body;
    const query = 'UPDATE tasks SET name = ?, date = ?, description = ?, status = ? WHERE id = ?';
    db.query(query, [name, date, description, status, id], (err) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao atualizar tarefa' });
        }
        res.sendStatus(204);
    });
});

// Rota para deletar tarefa
app.delete('/tasks/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM tasks WHERE id = ?';
    db.query(query, [id], (err) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao deletar tarefa' });
        }
        res.sendStatus(204);
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
