import styles from "./Subbar.module.css";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faClipboardList, faTasks, faStickyNote, faBook } from '@fortawesome/free-solid-svg-icons';

function Subbar() {
    return (
        <div className={styles.subbar}>
            <ul>
                <li className={styles.item}>
                    <Link to="/home">
                        <FontAwesomeIcon icon={faHome} /> Inicio
                    </Link>
                </li>

                <li className={styles.item}>
                    <Link to="/TodoList">
                        <FontAwesomeIcon icon={faClipboardList} /> To-do list
                    </Link>
                </li>

                <li className={styles.item}>
                    <Link to="/kanbam">
                        <FontAwesomeIcon icon={faTasks} /> Kanbam
                    </Link>
                </li>

                <li className={styles.item}>
                    <Link to="/notas">
                        <FontAwesomeIcon icon={faStickyNote} /> Notas
                    </Link>
                </li>

                <li className={styles.item}>
                    <Link to="/">
                        <FontAwesomeIcon icon={faBook} /> Seli
                    </Link>
                </li>
            </ul>
        </div>
    );
}

export default Subbar;
